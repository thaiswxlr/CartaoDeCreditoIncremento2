import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
    private ArrayList<CartaoDeCredito> cartoes;

    public Principal() {
        cartoes = new ArrayList<>();
    }

    public void adicionarCartao() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o número do cartão: ");
        String numero = scanner.nextLine();
        System.out.print("Digite o nome do titular: ");
        String nomeTitular = scanner.nextLine();
        
       
        System.out.print("Deseja definir um limite personalizado? (s/n): ");
        String resposta = scanner.nextLine();
        
        float limite;
        float taxaCashback = 0.0f;
        if (resposta.equalsIgnoreCase("s")) {
            System.out.print("Digite o limite do cartão: ");
            limite = scanner.nextFloat();
            System.out.print("Digite a taxa de cashback (em %): ");
            taxaCashback = scanner.nextFloat();
        } else {
            limite = 1000.0f; 
        }
        scanner.nextLine(); 

       
        CartaoDeCredito cartao = new CartaoDeCredito(numero, nomeTitular, limite, taxaCashback);
        cartoes.add(cartao);
        System.out.println("Cartão adicionado com sucesso!");

        scanner.close();
    }

    public void menu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Realizar Transação Básica");
            System.out.println("2. Realizar Transação com Cashback");
            System.out.println("3. Consultar Limite");
            System.out.println("4. Consultar Saldo");
            System.out.println("5. Adicionar Cartão");
            System.out.println("6. Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    if (cartoes.isEmpty()) {
                        System.out.println("Nenhum cartão cadastrado.");
                        break;
                    }
                    System.out.print("Escolha o índice do cartão (0 a " + (cartoes.size() - 1) + "): ");
                    int indexTransacao = scanner.nextInt();
                    System.out.print("Digite o valor da transação: ");
                    float valorTransacao = scanner.nextFloat();
                    System.out.println(cartoes.get(indexTransacao).realizarTransacao(valorTransacao));
                    break;
                case 2:
                    if (cartoes.isEmpty()) {
                        System.out.println("Nenhum cartão cadastrado.");
                        break;
                    }
                    System.out.print("Escolha o índice do cartão (0 a " + (cartoes.size() - 1) + "): ");
                    int indexCashback = scanner.nextInt();
                    System.out.print("Digite o valor da transação: ");
                    float valorCashback = scanner.nextFloat();
                    System.out.println(cartoes.get(indexCashback).realizarTransacao(valorCashback, true));
                    break;
                case 3:
                    if (cartoes.isEmpty()) {
                        System.out.println("Nenhum cartão cadastrado.");
                        break;
                    }
                    System.out.print("Escolha o índice do cartão (0 a " + (cartoes.size() - 1) + "): ");
                    int indexLimite = scanner.nextInt();
                    System.out.printf("Limite disponível: R$%.2f%n", cartoes.get(indexLimite).consultarLimite());
                    break;
                case 4:
                    if (cartoes.isEmpty()) {
                        System.out.println("Nenhum cartão cadastrado.");
                        break;
                    }
                    System.out.print("Escolha o índice do cartão (0 a " + (cartoes.size() - 1) + "): ");
                    int indexSaldo = scanner.nextInt();
                    System.out.printf("Saldo atual: R$%.2f%n", cartoes.get(indexSaldo).consultarSaldo());
                    break;
                case 5:
                    adicionarCartao();
                    break;
                case 6:
                    System.out.println("Saindo...");
                    return;
                default:
                    System.out.println("Opção inválida. Tente novamente.");

                scanner.close();
            }
        }
    }

    public static void main(String[] args) {
        Principal sistema = new Principal();
        sistema.menu();
    }
}
