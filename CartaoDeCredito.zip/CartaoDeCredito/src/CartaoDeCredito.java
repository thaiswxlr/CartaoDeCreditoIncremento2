public class CartaoDeCredito {
    private int numero;
    private String nomeTitular;
    String cpf;
    double limite;
    private double totalFatura;

    
    public CartaoDeCredito(int numero, String nomeTitular, String cpf, double limiteInicial) {
        this.numero = numero;
        this.nomeTitular = nomeTitular;
        this.cpf = cpf;
        this.limite = limiteInicial;
        this.totalFatura = 0.0;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNomeTitular() {
        return nomeTitular;
    }

    public void setNomeTitular(String nomeTitular) {
        this.nomeTitular = nomeTitular;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    public double getTotalFatura() {
        return totalFatura;
    }

    public void setTotalFatura(double totalFatura) {
        this.totalFatura = totalFatura;
    }

  
    public double consultarLimite() {
        return getLimite();
    }

    public double consultarTotalFatura() {
        return getTotalFatura();
    }

    public void realizarCompra(double valor) {
        if (valor <= 0) {
            System.out.println("O valor da compra deve ser positivo.");
            return;
        }
        
        if (valor <= getLimite()) {
            setLimite(getLimite() - valor);
            setTotalFatura(getTotalFatura() + valor);
            System.out.println("Compra realizada com sucesso!");
        } else {
            System.out.println("Você não possui limite necessário.");
        }
    }

    public void alterarLimite(double novoLimite) {
        if (novoLimite >= 0) {
            setLimite(novoLimite);
            System.out.println("Limite atualizado com sucesso.");
        } else {
            System.out.println("O limite não pode ser negativo.");
        }
    }
}
