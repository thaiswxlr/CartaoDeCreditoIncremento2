public class CartaoDeCredito {
    private String numero;
    private String nomeTitular;
    private String cpfTitular;
    private float limite;
    private float saldo;
    private float taxaCashback; 

   
    public CartaoDeCredito(String numero, String nomeTitular) {
        this.numero = numero;
        this.nomeTitular = nomeTitular;
        this.limite = 1000.0f; 
        this.saldo = limite;
        this.taxaCashback = 0.0f; 
    }

  
    public CartaoDeCredito(String numero, String nomeTitular, float limite, float taxaCashback) {
        this.numero = numero;
        this.nomeTitular = nomeTitular;
        this.limite = limite;
        this.saldo = limite;
        this.taxaCashback = taxaCashback;
    }

    public float consultarSaldo() {
        return saldo;
    }

    public float consultarLimite() {
        return limite;
    }

    public String realizarTransacao(float valor) {
        if (valor <= saldo) {
            saldo -= valor;
            return String.format("Transação de R$%.2f realizada com sucesso.", valor);
        } else {
            return "Transação negada: saldo insuficiente.";
        }
    }

    //
    public String realizarTransacao(float valor, boolean comCashback) {
        if (comCashback) {
            if (valor <= saldo) {
                saldo -= valor;
                float cashback = valor * (taxaCashback / 100);
                saldo += cashback; 
                return String.format("Transação de R$%.2f realizada com cashback de R$%.2f.", valor, cashback);
            } else {
                return "Transação negada: saldo insuficiente.";
            }
        }
        return realizarTransacao(valor); 
    }
}
